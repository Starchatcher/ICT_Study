package com.thedish.notice.service;

public class NoticeService {

}
