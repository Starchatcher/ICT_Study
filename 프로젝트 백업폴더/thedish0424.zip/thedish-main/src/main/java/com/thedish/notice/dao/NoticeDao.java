package com.thedish.notice.dao;

public class NoticeDao {

}
