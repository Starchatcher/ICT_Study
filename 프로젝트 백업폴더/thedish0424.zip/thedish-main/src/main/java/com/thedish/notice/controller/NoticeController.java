package com.thedish.notice.controller;

public class NoticeController {

}
