package com.thedish.recipe.exception;

public class RecipeException extends Exception {
	public RecipeException(String message) {
		super(message);
	}
}


