package com.thedish.board.exception;

public class BoardException extends Exception{
	public BoardException(String message) {
		super(message);
	}

}
