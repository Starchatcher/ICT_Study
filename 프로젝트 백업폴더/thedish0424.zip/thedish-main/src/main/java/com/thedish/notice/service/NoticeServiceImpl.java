package com.thedish.notice.service;

public class NoticeServiceImpl {

}
