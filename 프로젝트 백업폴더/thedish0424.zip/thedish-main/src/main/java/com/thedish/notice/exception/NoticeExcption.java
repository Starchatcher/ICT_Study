package com.thedish.notice.exception;

public class NoticeExcption {

}
